//#-hidden-code

//
//  Virus Shooter
//
//  Contents.swift
//  Created by Ayush Singh on 15/04/2021.
//  Copyright © 2021 Ayush Singh. All rights reserved.
//

//#-end-hidden-code

//: ## Virus Shooter
/*:
 ##
 ![](Virus-Shooter.png "Virus Shooter Image")
 
 Hi! I'm *Ayush Singh*, a first year student of Manipal University Jaipur,Rajhasthan, India. I've devoted to iOS development since 2017 and this year, and I have developed lots ios app for my school and university. I made some digging into the latest `ARKit`, which is awesome and easy to use! So I created a Virus Shooter game for WWDC 2021 scholarship submission. Hope you like it! 😊
 
 ### Welcome
 
 In order to let you get familiar with the game quickly, I gave you information about game. After tapping the `Run My Code` button, move your iPad around and fix the score node by shooting a bullet. Once done, a crosshair will show up in the center of the screen. Then, please use the front sight (also in the center of screen) to aim the Viruses, and tap the screen to shoot them!
 
 #### Notice
 
 * When the game starts, keep your iPad at the same height as your head to find the virus.
 * Scoring of game is when you shoot virus you got 1 point then points get increasing, and if you shoot the sanitizer then you will lose points and get negative scoring.
 * It is recommended to run the game in a **portrait** mode.
 * It is better to run game in **full screen portrait** mode.
 
 */


let gravity: UInt = 2

//#-hidden-code
import UIKit
import PlaygroundSupport

let viewController = ArcadeViewController(gravityValue: gravity)

PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
