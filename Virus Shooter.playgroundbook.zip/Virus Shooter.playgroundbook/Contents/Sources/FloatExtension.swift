
//
//  Virus Shooter
//
//  FloatExtension.swift
//  Created by Ayush Singh on 16/04/2021.
//  Copyright © 2021 Ayush Singh. All rights reserved.
//

import Foundation

extension Float {
    
    var squared: Float {
        return self * self
    }
    
}
