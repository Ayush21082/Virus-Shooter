
//
//  Virus Shooter
//
//  TargetNode.swift
//  Created by Ayush Singh on 17/04/2021.
//  Copyright © 2021 Ayush Singh. All rights reserved.
//

import UIKit
import SceneKit

public let targetRadius: CGFloat = 0.3

public enum CollisionCategory: Int {
    case bullet = 1
    case target = 2
    case floor  = 4
}

public enum TargetNodeTypeNum: Int {
    case greenvirus
    case bluevirus
    case sanitizer
    
    func getUIImageName() -> String {
        var str = ""
        switch self {
        case .greenvirus:
            str = "greenvirus"
        case .bluevirus:
            str = "bluevirus"
        case .sanitizer:
            str = "sanitizer"
        }
        return "target-\(str)"
    }
}

public struct TargetNodeType {
    var score: Int = 1
    var color: UIColor = .greenvirus
    var typeNum: TargetNodeTypeNum = .greenvirus
    
    init(typeNum: TargetNodeTypeNum) {
        self.typeNum = typeNum
        switch typeNum {
        case .greenvirus:
            score = 1
            color = .greenvirus
        case .bluevirus:
            score = 3
            color = .bluevirus
        case .sanitizer:
            score = -5
            color = .sanitizer
        }
    }
}

public class TargetNode: SCNNode {

    public var type: TargetNodeType?
    public var hit: Bool = false
    public var hitScore: Int {
        get {
            return hit ? 0 : (type?.score ?? 0) * scoreMultiple
        }
    }
    public var typeColor: UIColor {
        get {
            return type?.color ?? UIColor.clear
        }
    }
    public var radius: CGFloat = targetRadius
    var scoreMultiple: Int = 1
    
    public override init() {
        super.init()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public static func generateTarget() -> TargetNode {
        let targetNode = TargetNode()
        
        let cylinder = SCNCylinder(radius: CGFloat(arc4random() % 10) / 50.0 + 0.1, height: targetRadius / 10.0)
        targetNode.geometry = cylinder
        
        let shape = SCNPhysicsShape(geometry: cylinder, options: nil)
        targetNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
        targetNode.physicsBody?.isAffectedByGravity = true
        targetNode.physicsBody?.mass = 0.15
        
        targetNode.physicsBody?.categoryBitMask = CollisionCategory.target.rawValue
        targetNode.physicsBody?.contactTestBitMask = CollisionCategory.bullet.rawValue | CollisionCategory.floor.rawValue
        
        let material = SCNMaterial()
        let n = arc4random() % 10
        if n <= 1 {
            targetNode.type = TargetNodeType(typeNum: .bluevirus)
            material.diffuse.contents = UIImage(named: "target-bluevirus")
        } else if n >= 8 {
            targetNode.type = TargetNodeType(typeNum: .sanitizer)
            material.diffuse.contents = UIImage(named: "target-sanitizer")
        } else {
            targetNode.type = TargetNodeType(typeNum: .greenvirus)
            material.diffuse.contents = UIImage(named: "target-greenvirus")
        }
        let whiteMaterial = SCNMaterial()
        whiteMaterial.diffuse.contents = targetNode.typeColor
        targetNode.geometry?.materials = [whiteMaterial, material, material]
        
        return targetNode
    }
    
    public static func getSingleTarget(isTutorial: Bool) -> TargetNode {
        let targetNode = TargetNode()
        
        let cylinder = SCNCylinder(radius: targetRadius, height: targetRadius / 10.0)
        targetNode.geometry = cylinder
        
        let shape = SCNPhysicsShape(geometry: cylinder, options: nil)
        targetNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
        targetNode.physicsBody?.isAffectedByGravity = !isTutorial
        targetNode.physicsBody?.mass = 0.15
        
        targetNode.physicsBody?.categoryBitMask = CollisionCategory.target.rawValue
        targetNode.physicsBody?.contactTestBitMask = CollisionCategory.bullet.rawValue
        
        targetNode.type = TargetNodeType(typeNum: .greenvirus)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIImage(named: "target-greenvirus")
        let whiteMaterial = SCNMaterial()
        whiteMaterial.diffuse.contents = targetNode.typeColor
        targetNode.geometry?.materials = [whiteMaterial, material, material]
        
        return targetNode
    }
    
    public static func generateSmallTarget(oldTarget: TargetNode) -> TargetNode {
        let newRadius = oldTarget.radius * 0.8
        let targetNode = TargetNode()
        
        let cylinder = SCNCylinder(radius: newRadius, height: targetRadius / 10.0)
        targetNode.geometry = cylinder
        
        let shape = SCNPhysicsShape(geometry: cylinder, options: nil)
        targetNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
        targetNode.physicsBody?.isAffectedByGravity = true
        targetNode.physicsBody?.mass = 0.15
        
        targetNode.physicsBody?.categoryBitMask = CollisionCategory.target.rawValue
        targetNode.physicsBody?.contactTestBitMask = CollisionCategory.bullet.rawValue
        
        let material = SCNMaterial()
        
        let n = arc4random() % 10
        if n <= 1 {
            targetNode.type = TargetNodeType(typeNum: .bluevirus)
            material.diffuse.contents = UIImage(named: "target-bluevirus")
        } else if n >= 6 {
            targetNode.type = TargetNodeType(typeNum: .sanitizer)
            material.diffuse.contents = UIImage(named: "target-sanitizer")
        } else {
            targetNode.type = TargetNodeType(typeNum: .greenvirus)
            material.diffuse.contents = UIImage(named: "target-greenvirus")
        }
        
        let whiteMaterial = SCNMaterial()
        whiteMaterial.diffuse.contents = targetNode.typeColor
        targetNode.geometry?.materials = [whiteMaterial, material, material]
        
        targetNode.radius = newRadius
        targetNode.scoreMultiple = oldTarget.scoreMultiple * 2
        
        return targetNode
    }
    
}
